public class Hotel {
    private double hotelRevenue;
    private String hotelName;
    private int  hotelRoomNumber;
    private int hotelRoomFloor;
    private String roomAvailability;
    private double hotelRoomCharges;

    private String customerName;
    private String customerEmail;
    private double customerBalance;
    private long customerContact;

    private String hotelRentHistory;

    public Hotel(String hotelName, int hotelRoomNumber, int hotelRoomFloor, String roomAvailability, double hotelRoomCharges) {
        this.hotelName = hotelName;

        this.hotelRoomNumber = hotelRoomNumber;
        this.hotelRoomFloor = hotelRoomFloor;
        this.roomAvailability = roomAvailability;
        this.hotelRoomCharges = hotelRoomCharges;
    }

    public Hotel(String customerName, String customerEmail, double customerBalance, long customerContact) {
        this.customerName = customerName;
        this.customerEmail = customerEmail;
        this.customerBalance = customerBalance;
        this.customerContact = customerContact;
    }

    public Hotel(double hotelRoomCharges) {
        this.hotelRoomCharges = hotelRoomCharges;
    }

    public Hotel(String hotelRentHistory) {
        this.hotelRentHistory = hotelRentHistory;
    }

    public String getHotelName() {
        return hotelName;
    }

    public void setHotelName(String hotelName) {
        this.hotelName = hotelName;
    }


    public int getHotelRoomNumber() {
        return hotelRoomNumber;
    }

    public void setHotelRoomNumber(int hotelRoomNumber) {
        this.hotelRoomNumber = hotelRoomNumber;
    }

    public int getHotelRoomFloor() {
        return hotelRoomFloor;
    }

    public void setHotelRoomFloor(int hotelRoomFloor) {
        this.hotelRoomFloor = hotelRoomFloor;
    }

    public String getRoomAvailability() {
        return roomAvailability;
    }

    public void setRoomAvailability(String roomAvailability) {
        this.roomAvailability = roomAvailability;
    }

    public double getHotelRoomCharges() {
        return hotelRoomCharges;
    }

    public void setHotelRoomCharges(double hotelRoomCharges) {
        this.hotelRoomCharges = hotelRoomCharges;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }

    public double getCustomerBalance() {
        return customerBalance;
    }

    public void setCustomerBalance(double customerBalance) {
        this.customerBalance = customerBalance;
    }

    public long getCustomerContact() {
        return customerContact;
    }

    public void setCustomerContact(long customerContact) {
        this.customerContact = customerContact;
    }

    public double getHotelRevenue() {
        return hotelRevenue;
    }

    public void setHotelRevenue(double hotelRevenue) {
        this.hotelRevenue = hotelRevenue;
    }

    public String getHotelRentHistory() {
        return hotelRentHistory;
    }

    public void setHotelRentHistory(String hotelRentHistory) {
        this.hotelRentHistory = hotelRentHistory;
    }

    @Override
    public String toString() {
        return "Hotel{" +
                "hotelRevenue=" + hotelRevenue +
                ", hotelName='" + hotelName + '\'' +
                ", hotelRoomNumber=" + hotelRoomNumber +
                ", hotelRoomFloor=" + hotelRoomFloor +
                ", roomAvailability='" + roomAvailability + '\'' +
                ", hotelRoomCharges=" + hotelRoomCharges +
                ", customerName='" + customerName + '\'' +
                ", customerEmail='" + customerEmail + '\'' +
                ", customerBalance=" + customerBalance +
                ", customerContact=" + customerContact +
                ", hotelRentHistory='" + hotelRentHistory + '\'' +
                '}';
    }
}
