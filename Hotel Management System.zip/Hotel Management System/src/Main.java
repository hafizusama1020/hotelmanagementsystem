import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        String hotelRoomAvailability;
        int  hotelRoomNumber;
        int hotelRoomFloor;
        double hotelRoomCharges;
        String hotelName;

        Scanner sc=new Scanner(System.in);
        ArrayList<AssigningRooms> list=new ArrayList<>();
        ArrayList<CustomersManagement> list2=new ArrayList<>();
        ArrayList<HotelRentHistory> list3= new ArrayList<>();

        AssigningRooms ar=new AssigningRooms("Paradise",1,1,"Available",5000);
        ComputingPayments cp = new ComputingPayments(ar.getHotelRoomCharges());
        CustomersManagement cm= new CustomersManagement("hafizUsama","hafizusama747@gmail.com",25000,12345);
        HotelRooms hm= new HotelRooms("Paradise",1,1,"Available",5000);
        list.add(ar);
        list2.add(cm);


        int choice = 10;
        while (choice != 0) {
            System.out.println("***Main Menu***");
            System.out.println("1.Manage Hotel Rooms");
            System.out.println("2.List all Hotel Rooms");
            System.out.println("3.Rent Hotel Room as a Customer");
            System.out.println("4.Show Hotel Rent history history");
            System.out.println("5.Show Hotel Revenue");
            System.out.println("6.Exit");
            choice = sc.nextInt();
            if (choice == 1) {
                System.out.println("\n***Select your option***");
                System.out.println("1.Add new Hotel Room");
                System.out.println("2.Delete room");
                System.out.println("3.Update room");
                System.out.println("4.Search room");
                int manageItemChoice = sc.nextInt();
                if (manageItemChoice == 1) {
                    if (choice == 1) {

                        System.out.println("Enter Hotel name");
                        sc.nextLine();
                        hotelName = sc.nextLine();

                        System.out.println("Enter Room number");
                        sc.nextLine();
                        hotelRoomNumber = sc.nextInt();

                        System.out.println("Enter room floor");
                        hotelRoomFloor = sc.nextInt();
                        System.out.println("Enter room availability");
                        hotelRoomAvailability = sc.nextLine();
                        System.out.println("Enter room charges");
                        hotelRoomCharges = sc.nextDouble();

                        ar.addHotelRoom(list,hotelName,hotelRoomNumber,hotelRoomFloor,hotelRoomAvailability,hotelRoomCharges);
                        System.out.println("Room added successfully");
                    }
                }
                else if(manageItemChoice==2){
                    System.out.println("Delete room by room Number");

                        System.out.println("Enter the room number you want to delete");
                        int delNumber;
                        sc.nextLine();
                        delNumber=sc.nextInt();
                        ar.deleteRoom(list,delNumber);

                }
                else if(manageItemChoice==3){
                    System.out.println("Update room by room Number");


                        System.out.println("Enter the room number you want to update");
                       int roomNumUpdate;
                        roomNumUpdate=sc.nextInt();
                        ar.updateRoom(list,roomNumUpdate);

                }
                else if(manageItemChoice==4){

                    System.out.println("Search room by room number");

                        System.out.println("Enter the room number you want to search");
                        int searchRoom;
                        searchRoom=sc.nextInt();
                        ar.searchItem(list,searchRoom);
                }
            }
            else if(choice==2){
                hm.displayHotelRooms(list);
            }
            else if(choice==3){
                System.out.println("Enter the room number you want to rent");
                int itemPurchaseID=sc.nextInt();
                cm.rentHotelRoom(list,list3,list2,itemPurchaseID);
            }
            else if(choice==4){
                System.out.println(list3);
            }
            else if(choice==5)
            {
                System.out.println(ar.getHotelRevenue());
            }
            else if(choice==6){
                choice=0;
            }
            else{
                System.out.println("Wrong choice");
            }
        }

    }
}
