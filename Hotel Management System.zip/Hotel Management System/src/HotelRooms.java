import java.util.ArrayList;

public class HotelRooms extends Hotel {
    public HotelRooms(String hotelName, int hotelRoomNumber, int hotelRoomFloor, String roomAvailability, double hotelRoomCharges) {
        super(hotelName, hotelRoomNumber, hotelRoomFloor, roomAvailability, hotelRoomCharges);
    }
        public void displayHotelRooms(ArrayList<AssigningRooms> list){
            System.out.println("All room details of the hotel");
            System.out.println(list);
        }
    @Override
    public String toString() {
        return "HotelRooms{" +
                ", hotelName='" + getHotelName() + '\'' +
                ", hotelRoomNumber=" + getHotelRoomNumber() +
                ", hotelRoomFloor=" + getHotelRoomFloor() +
                ", roomAvailability='" + getRoomAvailability() + '\'' +
                ", hotelRoomCharges=" + getHotelRoomCharges() +
                '}';
    }
}


