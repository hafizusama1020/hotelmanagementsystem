import java.util.ArrayList;

public class HotelRentHistory extends Hotel{
    public HotelRentHistory(String hotelRentHistory) {
        super(hotelRentHistory);
    }

    public void showHotelRentHistory(ArrayList<HotelRentHistory> list) {
        System.out.println(list);
    }

    public void deleteSalePurchaseRecords(ArrayList<HotelRentHistory> list) {
        list.clear();
        System.out.println("Records deleted successfully");
    }
    @Override
    public String toString() {
        return "Hotel Rent History{" +
                ", hotelRentHistory='" + getHotelRentHistory() + '\'' +
                '}';
    }

}
