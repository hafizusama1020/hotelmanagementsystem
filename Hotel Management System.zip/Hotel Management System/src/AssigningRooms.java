import java.util.ArrayList;
import java.util.Scanner;

public class AssigningRooms extends Hotel {
    public AssigningRooms(String hotelName, int hotelRoomNumber, int hotelRoomFloor, String roomAvailability, double hotelRoomCharges) {
        super(hotelName, hotelRoomNumber, hotelRoomFloor, roomAvailability, hotelRoomCharges);
    }

    public void addHotelRoom(ArrayList<AssigningRooms> list, String hotelName, int hotelRoomNumber, int hotelRoomFloor, String roomAvailability, double hotelRoomCharges) {
        list.add(new AssigningRooms(hotelName, hotelRoomNumber, hotelRoomFloor, roomAvailability, hotelRoomCharges));
        System.out.println("Room added successfully");
    }

    // search hotel room method it can search room by id and returns 1 if room is found else returns 0
    int searchItem(ArrayList<AssigningRooms> list, int roomNumber) {
        int flag = 0;

        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getHotelRoomNumber() == roomNumber) {
                flag = 1;
                System.out.println("Room found" + list.get(i));
            }
        }

        return flag;
    }

    // delete room method by ID
    public void deleteRoom(ArrayList<AssigningRooms> list, int roomNumber) {

        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getHotelRoomNumber() == roomNumber) {
                list.remove(i);
                System.out.println("Room deleted successfully!");
            } else {
                System.out.println("Invalid Room ID");
            }
        }
    }

// room data update method either by ID

    Scanner sc = new Scanner(System.in);

    public void updateRoom(ArrayList<AssigningRooms> list, int roomNumber) {

        // updating by ID
        if (searchItem(list, roomNumber) == 1) {
            System.out.println("Which attribute of the room do you want to update");
            System.out.println("1.Room Number");
            System.out.println("2.Room floor");
            System.out.println("3.Room availability");
            System.out.println("4.Room charges");

            int choice;
            choice = sc.nextInt();
            if (choice == 1) {
                System.out.println("Enter new room number");
                sc.nextLine();
                int newRoomNumber;
                newRoomNumber = sc.nextInt();
                for (int i = 0; i < list.size(); i++) {
                    if (list.get(i).getHotelRoomNumber() == roomNumber) {
                        list.get(i).setHotelRoomNumber(newRoomNumber);
                        System.out.println("Room number updated successfully");
                    }
                }
            } else if (choice == 2) {
                System.out.println("Enter new room floor");
                int newRoomFloor;
                newRoomFloor = sc.nextInt();
                for (int i = 0; i < list.size(); i++) {
                    if (list.get(i).getHotelRoomNumber() == roomNumber) {
                        list.get(i).setHotelRoomFloor(newRoomFloor);
                        System.out.println("Room floor updated successfully");
                    }
                }

            } else if (choice == 3) {
                System.out.println("Enter new room availability");
                String newRoomAvailability;
                sc.nextLine();
                newRoomAvailability = sc.nextLine();
                for (int i = 0; i < list.size(); i++) {
                    if (list.get(i).getHotelRoomNumber() == roomNumber) {
                        list.get(i).setRoomAvailability(newRoomAvailability);
                        System.out.println("Room availability updated successfully");
                    }
                }

            } else if (choice == 4) {
                System.out.println("Enter new room charges");
                double newRoomCharges;
                sc.nextLine();
                newRoomCharges = sc.nextDouble();
                for (int i = 0; i < list.size(); i++) {
                    if (list.get(i).getHotelRoomNumber() == roomNumber) {
                        list.get(i).setHotelRoomCharges(newRoomCharges);
                        System.out.println("Room charges updated successfully");
                    }
                }
            } else {
                System.out.println("Wrong choice");
            }
        }
    }

    @Override
    public String toString() {
        return "Room details{" +
                ", Hotel Name='" + getHotelName() + '\'' +
                ", Room Number=" + getHotelRoomNumber() +
                ", Room Floor=" + getHotelRoomFloor() +
                ", Availability='" + getRoomAvailability() + '\'' +
                ", Room Charges=" + getHotelRoomCharges() +
                '}';
    }
}