import java.util.ArrayList;
import java.util.Scanner;

public class ComputingPayments extends Hotel{
    public ComputingPayments(double hotelRoomCharges) {
        super(hotelRoomCharges);
    }

    //method to show a particular room charges
    public void showRoomCharges(ArrayList<AssigningRooms> list, int roomNumber){
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getHotelRoomNumber() == roomNumber) {
                System.out.print("Room charges :");
                System.out.println(list.get(i).getHotelRoomCharges());
                System.out.println(" Per day");
            }
        }
    }

    Scanner sc=new Scanner(System.in);
    public void updateRoomCharges(ArrayList<AssigningRooms> list,int roomNumber){
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getHotelRoomNumber() == roomNumber) {
                System.out.println("Enter new charges for the room");
                double newRoomCharges=sc.nextDouble();
                list.get(i).setHotelRoomCharges(newRoomCharges);
                System.out.println("Room charges Updated Successfully!");
            }
        }
    }
    @Override
    public String toString() {
        return "Computing Payments{" +
                ", hotelRoomCharges=" + getHotelRoomCharges() +
                '}';
    }
}
