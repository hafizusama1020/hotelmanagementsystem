import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Scanner;

public class CustomersManagement extends Hotel{

    public CustomersManagement(String customerName, String customerEmail, double customerBalance, long customerContact) {
        super(customerName, customerEmail, customerBalance, customerContact);
    }
    Scanner sc=new Scanner(System.in);
    public void rentHotelRoom(ArrayList<AssigningRooms> list, ArrayList<HotelRentHistory> list4, ArrayList<CustomersManagement> list2, int roomNumber) {

        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getHotelRoomNumber() == roomNumber) {
                System.out.println(list.get(i));
                System.out.println("Room Availability");
                System.out.println(list.get(i).getRoomAvailability());
                System.out.println("Enter the amount of days for which you want to rent the room");
                int buyItem = sc.nextInt();
                if(list2.get(0).getCustomerBalance()<list.get(i).getHotelRoomCharges()*buyItem){
                    System.out.println("Not enough account balance to rent the room");
                }
                else if (list.get(i).getRoomAvailability().equals("Available") || list.get(i).getRoomAvailability().equals("available")) {
                    System.out.println("Room is Available");
                    System.out.println("Your previous account balance");
                    System.out.println("          " + list2.get(0).getCustomerBalance());
                    System.out.println("***Room Successfully Rented***\n***Enjoy your stay here***");
                    list2.get(0).setCustomerBalance(list2.get(0).getCustomerBalance() - list.get(i).getHotelRoomCharges() * buyItem);
                    System.out.println("Account balance after purchase");
                    System.out.println("            " + list2.get(0).getCustomerBalance());
                    System.out.println("*********************************");
                    list.get(i).setHotelRevenue(getHotelRevenue() + list.get(i).getHotelRoomCharges() * buyItem);
                    LocalTime time = LocalTime.now();
                    String s = (list2.get(0).getCustomerName() + " rented " + " room " + roomNumber + " for " + list.get(i).getHotelRoomCharges() * buyItem + " for " + buyItem + " days " + " at time " + time);
                    list4.add(new HotelRentHistory(s));
                    list.get(i).setRoomAvailability("not available");
                } else {
                    System.out.println("Room is not available");
                }
            }
        }
    }
    @Override
    public String toString() {
        return "Customers Management{" +
                ", customerName='" + getCustomerName() + '\'' +
                ", customerEmail='" + getCustomerEmail() + '\'' +
                ", customerBalance=" + getCustomerBalance() +
                ", customerContact=" + getCustomerContact() +
                '}';
    }
}
